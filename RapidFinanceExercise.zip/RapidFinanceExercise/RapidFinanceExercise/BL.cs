﻿using RapidFinanceExercise.Models;
using System;
using System.Collections.Generic;
using System.IO;

namespace RapidFinanceExercise
{
    public class BL
    {
        //Returns a string of the file specified in the filename parameter.
        public static string getData(string filename)
        {
            string lines = File.ReadAllText(filename);

            return lines;
        }
        //Delimits input string given by getData, and places it into a List to be called by getCommaList().
        public static List<string> loadComma(string filename)
        {
            string data = getData(filename);
            List<string> dataList = new List<string>(data.Split(',', '\n'));
            return dataList;
        }
        //Delimits input string given by getData, and places it into a List to be called by getHashList().
        public static List<string> loadHash(string filename)
        {
            string data = getData(filename);
            List<string> dataList = new List<string>(data.Split('#', '\n'));
            return dataList;
        }
        //Delimits input string given by getData, and places it into a List to be called by getHyphenList().
        public static List<string> loadHyphen(string filename)
        {
            string data = getData(filename);
            List<string> dataList = new List<string>(data.Split('-', '\n'));
            return dataList;
        }
        //Loads the files delimited by a , into it's model.
        public static List<commaM> getCommaList()
        {
            List<string> initCommaList = loadComma("Code_Exercise_Inputs/comma.txt");
            List<commaM> commaList = new List<commaM>();

            for (int x = 0; x < initCommaList.Count; x += 5)
            {
                commaList.Add(new commaM()
                {
                    CompanyName = initCommaList[x].Trim(),
                    ContactName = initCommaList[x + 1].Trim(),
                    ContactPhoneNumber = initCommaList[x + 2].Trim(),
                    YearsIB = initCommaList[x + 3].Trim(),
                    ContactEmail = initCommaList[x + 4].Trim()
                });
            }
            return commaList;
        }
        //Loads the files delimited by a # into it's model.
        public static List<hashM> getHashList()
        {
            List<string> initHashList = loadHash("Code_Exercise_Inputs/hash.txt");
            List<hashM> hashList = new List<hashM>();
            int currentYear = DateTime.Now.Year;

            for (int x = 0; x < initHashList.Count; x += 4)
            {
                int yearsInBusiness = currentYear - Convert.ToInt32(initHashList[x + 1].Trim());

                hashList.Add(new hashM()
                {
                    CompanyName = initHashList[x].Trim(),
                    YearsIB = yearsInBusiness.ToString(),
                    ContactName = initHashList[x + 2].Trim(),
                    ContactPhone = initHashList[x + 3].Trim()
                });
            }
            return hashList;
        }
        //Loads the files delimited by a - into it's model.
        public static List<hyphenM> getHyphenList()
        {
            List<string> initHyphenList = loadHyphen("Code_Exercise_Inputs/hyphen.txt");
            List<hyphenM> hyphenList = new List<hyphenM>();

            int currentYear = DateTime.Now.Year;

            for (int x = 0; x < initHyphenList.Count; x += 6)
            {
                int yearsInBusiness = currentYear - Convert.ToInt32(initHyphenList[x + 1].Trim());

                hyphenList.Add(new hyphenM()
                {
                    CompanyName = initHyphenList[x].Trim(),
                    YearsIB = yearsInBusiness.ToString(),
                    ContactPhone = initHyphenList[x + 2].Trim(),
                    ContactEmail = initHyphenList[x + 3].Trim(),
                    ContactFirstName = initHyphenList[x + 4].Trim(),
                    ContactLastName = initHyphenList[x + 5].Trim()
                });
            }
            return hyphenList;
        }
        //Combines the models into one master model that is used to display data in the view.
        public static List<combinedValues> getCombinedList(List<commaM> commaList, List<hashM> hashList, List<hyphenM> hyphenList)
        {
            List<combinedValues> result = new List<combinedValues>();

            //Loads the comma model (model of data delimited by ',') into the master model.
            for (int x = 0; x < commaList.Count; x++)
            {
                result.Add(new combinedValues()
                {
                    CompanyName = commaList[x].CompanyName,
                    YearsIB = commaList[x].YearsIB,
                    ContactName = commaList[x].ContactName,
                    PhoneNumber = commaList[x].ContactPhoneNumber,
                    ContactEmail = commaList[x].ContactEmail
                });
            }
            //Loads the hash model (model of data delimited by '#') into the master model.
            for (int x = 0; x < hashList.Count; x++)
            {
                result.Add(new combinedValues()
                {
                    CompanyName = hashList[x].CompanyName,
                    YearsIB = hashList[x].YearsIB,
                    ContactName = hashList[x].ContactName,
                    PhoneNumber = hashList[x].ContactPhone,
                    ContactEmail = "No email provided"
                });
            }
            //Loads the hyphen model (model of data delimited by '-') into the master model.
            for (int x = 0; x < hyphenList.Count; x++)
            {
                result.Add(new combinedValues()
                {
                    CompanyName = hyphenList[x].CompanyName,
                    YearsIB = hyphenList[x].YearsIB,
                    ContactName = hyphenList[x].ContactFirstName + " " + hyphenList[x].ContactLastName,
                    PhoneNumber = hyphenList[x].ContactPhone,
                    ContactEmail = hyphenList[x].ContactEmail
                });
            }
            //returns combined model made up of each input's models
            return result;
        }
    }
}
