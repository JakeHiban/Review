﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using RapidFinanceExercise.Models;
using System.Diagnostics;

namespace RapidFinanceExercise.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            //Places all of the files in one combined list, then places it in a viewbag. 
            //Works by placing each file into their own models, then combining those in the getCombinedList
            //method, which returns a list with a model of the five fields that are to be displayed in the
            //view(Company Name, Years in Business, Contact Name, Contact Phone Number, Contact Email).

            ViewBag.resultVB = BL.getCombinedList(BL.getCommaList(),BL.getHashList(),BL.getHyphenList());

            return View();
        }
        
        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}