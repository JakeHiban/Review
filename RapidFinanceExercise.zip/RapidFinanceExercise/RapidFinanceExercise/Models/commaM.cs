﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RapidFinanceExercise.Models
{
    public class commaM
    {
        //Company Name, Contact Name, Contact Phone Number, Years in business, Contact Email
        public string CompanyName { get; set; }
        public string ContactName { get; set; }
        public string ContactPhoneNumber { get; set; }
        public string YearsIB { get; set; }
        public string ContactEmail { get; set; }

    }
}
