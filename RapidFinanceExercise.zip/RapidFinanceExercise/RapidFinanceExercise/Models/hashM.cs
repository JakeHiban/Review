﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RapidFinanceExercise.Models
{
    public class hashM
    {
        //Company Name, Year Founded, Contact Name, Contact Phone Number
        public string CompanyName { get; set; }
        public string YearsIB { get; set; }
        public string ContactName { get; set; }
        public string ContactPhone { get; set; }
    }
}
